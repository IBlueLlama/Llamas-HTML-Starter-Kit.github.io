console.log("Hello World!")
//$("Select Item").What happens(What happens pt.2)
$("#Template").text("Template...")
$("p").css("color", "red");